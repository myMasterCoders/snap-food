function n(r){return new Intl.NumberFormat().format(r)}export{n};
