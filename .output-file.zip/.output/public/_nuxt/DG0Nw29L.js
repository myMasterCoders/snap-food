import{ai as a,a0 as t,D as s}from"./CEHpqohg.js";const u=a(()=>{const{user:e}=t();if(e.value)return s("/")});export{u as default};
