import{ai as e,a0 as t,D as s}from"./CEHpqohg.js";const r=e(()=>{const{user:a}=t();if(!a.value)return s("/Login")});export{r as default};
